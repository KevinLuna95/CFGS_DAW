package es.ifp.programacion.uf1.practica.ejercicio1;

import java.util.Scanner;

/**
 * Programando la soluci�n para la primera pr�ctica evaluable de la UF1 de programaci�n.
 * El Lenguaje utilizado es Java
 * 
 * El programa debe ser una calculadora que acepte n�meros decimales que permita:
 * -Sumar
 * -Restar
 * -Multiplicar
 * -Dividir
 * -Resto
 * -Salir
 * Se debe ejecutar en bucle hasta que el usuario indique salir
 * 
 * La entrada a la operaci�n se tendra que hacer desde consola tanto indicando el n�mero de la operaci�n como indicando el s�mbolo de la operaci�n
 * 
 * @author Kevin
 * @version 1.0.0
 *
 */
public class ProgramaPrincipal {

	public static void main(String[] args) {
		// Declaraci�n de variables
		Scanner sc = new Scanner(System.in);
		
		float num1 = 0.0f, num2 = 0.0f, resultado = 0.0f;
		char operacion = 'x';
		
		//Bucle do-while para la solicitud de datos al usuario
		do {
			//Men�
		System.out.println("============ CALCULADORA :: GESTI�N DE AGUAS, SL ============");
		System.out.println("1. Sumar (+)");
		System.out.println("2. Restar (-)");
		System.out.println("3. Multiplicar (*)");
		System.out.println("4. Dividir (/)");
		System.out.println("5. Resto. (%)");
		System.out.println("0. Salir (S o s)");
		System.out.println("Introduzca una opcion del menu:");
		//Entrada de datos
		operacion = sc.nextLine().charAt(0);

		//sentencia Switch para el manejo de la opci�n escogida por el usuario.
		switch (operacion){
			case '1','+':
				//Solicitud de datos para realizar la suma
				System.out.println("Introduzca el primer numero:");
				num1 = Float.parseFloat(sc.nextLine());
				
				System.out.println("Introduzca el segundo numero:");
				num2 = Float.parseFloat(sc.nextLine());
				//transformaci�n y salida de datos
				resultado = num1 + num2;
				System.out.println("===================================");
				System.out.println("La suma de "+num1+" y "+num2+" es "+resultado);
				System.out.println("===================================");
				break;
			case '2','-':
				//Solicitud de datos para realizar la resta
				System.out.println("Introduzca el primer numero:");
				num1 = Float.parseFloat(sc.nextLine());
				
				System.out.println("Introduzca el segundo numero:");
				num2 = Float.parseFloat(sc.nextLine());
				//transformaci�n y salida de datos
				resultado = num1 - num2;
				System.out.println("===================================");
				System.out.println("La resta de "+num1+" y "+num2+" es "+resultado);
				System.out.println("===================================");
				break;
			case '3','*':
				//Solicitud de datos para realizar la multiplicacion
				System.out.println("Introduzca el primer numero:");
				num1 = Float.parseFloat(sc.nextLine());
				
				System.out.println("Introduzca el segundo numero:");
				num2 = Float.parseFloat(sc.nextLine());
				//transformaci�n y salida de datos
				resultado = num1 * num2;
				System.out.println("===================================");
				System.out.println("La multiplicacion de "+num1+" y "+num2+" es "+resultado);
				System.out.println("===================================");
				break;
			case '4','/':
				//Solicitud de datos para realizar la division
				System.out.println("Introduzca el primer numero:");
				num1 = Float.parseFloat(sc.nextLine());
				
				System.out.println("Introduzca el segundo numero:");
				num2 = Float.parseFloat(sc.nextLine());
				//transformaci�n y salida de datos
				resultado = num1 / num2;
				System.out.println("===================================");
				System.out.println("La division entre "+num1+" y "+num2+" es "+resultado);
				System.out.println("===================================");
				break;
			case '5','%':
				//Solicitud de datos para realizar el resto
				System.out.println("Introduzca el primer numero:");
				num1 = Float.parseFloat(sc.nextLine());
				
				System.out.println("Introduzca el segundo numero:");
				num2 = Float.parseFloat(sc.nextLine());
				//transformaci�n y salida de datos
				resultado = num1 % num2;
				System.out.println("===================================");
				System.out.println("El resto entre "+num1+" y "+num2+" es "+resultado);
				System.out.println("===================================");
				break;
			case '0','s','S':
				//Finalizando el programa
				System.out.println("El programa ha finalizado");
				break;
			default:
				//El ejercicio indica que en caso de no introducir un n�mero entre 0 y 6 debe indicar opcion incorrecta.
				//Observo 2 defectos: 1- La introducci�n de datos es de numeros entre 0 y 5 && 2- La entrada del usuario son tambien s�mbolos y letras
				//Si no se manejan el resto de errores puede interferir en la experiencia de usuorio negativamente.

				System.out.println("Opcion incorrecta");
				break;
		}
		//Fin del bucle while al cumplir con la condici�n
		} while  (operacion != '0' && operacion != 's' && operacion != 'S');
	}
}
