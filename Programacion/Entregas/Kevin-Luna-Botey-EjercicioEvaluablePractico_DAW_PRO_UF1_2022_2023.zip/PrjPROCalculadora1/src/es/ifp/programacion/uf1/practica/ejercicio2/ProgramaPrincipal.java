package es.ifp.programacion.uf1.practica.ejercicio2;
import java.util.Scanner;
/**
 * Programando la soluci�n para la primera pr�ctica evaluable de la UF1 de programaci�n.
 * El Lenguaje utilizado es Java
 * 
 * El programa debe ser una calculadora que acepte n�meros decimales que permita:
 * -Sumar
 * -Restar
 * -Multiplicar
 * -Dividir
 * -Resto
 * -Salir
 * Se debe ejecutar en bucle hasta que el usuario indique salir
 * 
 * La entrada a la operaci�n se tendra que hacer desde consola tanto indicando el n�mero de la operaci�n como indicando el s�mbolo de la operaci�n
 * 
 * @author Kevin
 * @version 1.0.0
 *
 */
public class ProgramaPrincipal {
	
	public static void main(String[] args) {
		//Invoco al procedimiento calculadora para que m�s adelante pueda llamarse a si mismo simulando un bucle.
		calculadora();
	}
	
	public static void calculadora () {
		//Declaraci�n de variables
		Scanner sc = new Scanner(System.in);
		float num1 = 0.0f,num2 = 0.0f;
		int numEntero = 0 ;
		char operacion = 0;
		
		//Impresi�n por pantalla del men�
		System.out.println("============ CALCULADORA :: GESTI�N DE AGUAS, SL ============");
		System.out.println("1. Sumar (+)");
		System.out.println("2. Restar (-)");
		System.out.println("3. Multiplicar (*)");
		System.out.println("4. Dividir (/)");
		System.out.println("5. Factorial. (!)");
		System.out.println("0. Salir (S o s)");
		System.out.println("Introduzca una opcion del menu:");
		operacion = sc.nextLine().charAt(0);
		
		//Sentencia switch para el manejo de las opciones escogidas por el usuario.
		switch (operacion){
		
			case '1','+': 
				//Entrada de datos
				System.out.println("Introduzca el primer n�mero:");
				num1 = Float.parseFloat(sc.nextLine());
				System.out.println("Introduzca el segundo n�mero:");
				num2 = Float.parseFloat(sc.nextLine());
				System.out.println("=======================================");
				System.out.println("La suma de "+num1+" y "+num2+" es "+sumar(num1,num2));
				System.out.println("=======================================");
				break;
				
			case '2','-': 
				//Entrada de datos
				System.out.println("Introduzca el primer n�mero:");
				num1 = Float.parseFloat(sc.nextLine());
				System.out.println("Introduzca el segundo n�mero:");
				num2 = Float.parseFloat(sc.nextLine());
				System.out.println("=======================================");
				System.out.println("La resta de "+num1+" y "+num2+" es "+restar(num1,num2)); 
				System.out.println("=======================================");
				break;
			
			case '3','*': 
				//Entrada de datos
				System.out.println("Introduzca el primer n�mero:");
				num1 = Float.parseFloat(sc.nextLine());
				System.out.println("Introduzca el segundo n�mero:");
				num2 = Float.parseFloat(sc.nextLine());
				System.out.println("=======================================");
				System.out.println("La multiplic�n de "+num1+" y "+num2+" es "+multiplicar(num1,num2)); 
				System.out.println("=======================================");
				break;
	
			case '4','/': 
				//Entrada de datos
				System.out.println("Introduzca el primer n�mero:");
				num1 = Float.parseFloat(sc.nextLine());
				System.out.println("Introduzca el segundo n�mero:");
				num2 = Float.parseFloat(sc.nextLine());
				System.out.println("=======================================");
				System.out.println("La divisi�n de "+num1+" y "+num2+" es "+dividir(num1,num2)); 
				System.out.println("=======================================");
				break;
	
			case '5','!': 
				//Entrada de datos
				System.out.println("Introduzca el n�mero: (Inferior a 170)");
				numEntero = Integer.parseInt(sc.nextLine());
				//no est� permitido obtener el factorial de 0 o inferior
				if(numEntero <= 0) 
					System.out.println("Error, valor no v�lido. Introduzca un valor superior a 0");
				else {
					System.out.println("=======================================");
					System.out.println("El factorial de "+numEntero+" es "+factorial(numEntero)); 
					System.out.println("=======================================");
				}
				break;
				
			case '0','s','S': 
				System.out.println("El programa ha finalizado");
				break;
			
			default: System.out.println(operacion+" Opci�n incorrecta");
			break;
			}
		
		//Este if controla la repetici�n del programa
		if (operacion != '0' && operacion != 's' && operacion != 'S')
		calculadora();
	}
	
	//Declaraci�n de las funciones
	
	/**
	 * La funci�n sumar realiza una operaci�n de suma de 2 par�metros
	 * @param num1 introducci�n de un n�mero float que posteriormente ser� sumado con param num2
	 * @param num2 introducci�n de un n�mero float que posteriormente ser� sumado con param num1
	 * @return num1+num2
	 */
	public static float sumar (float num1, float num2) {
		return num1+num2;
	}
	
	/**
	 * La funci�n restar realiza una operaci�n de resta de 2 par�metros
	 * @param num1 introducci�n de un n�mero float que posteriormente ser� restado con param num2
	 * @param num2 introducci�n de un n�mero float que posteriormente ser� restado con param num1
	 * @return num1-num2
	 */
	public static float restar (float num1, float num2) {
		return num1-num2;
	}
	
	/**
	 * La funci�n multiplicar realiza una operaci�n de multiplicar de 2 par�metros
	 * @param num1 introducci�n de un n�mero float que posteriormente ser� multiplicado con param num2
	 * @param num2 introducci�n de un n�mero float que posteriormente ser� multiplicado con param num1
	 * @return num1*num2
	 */
	public static float multiplicar (float num1, float num2) {
		return num1*num2;
	}
	
	/**
	 * La funci�n dividir realiza una operaci�n de dividir de 2 par�metros
	 * @param num1 introducci�n de un n�mero float que posteriormente ser� dividido con param num2
	 * @param num2 introducci�n de un n�mero float que posteriormente ser� dividido con param num1
	 * @return num1/num2
	 */
	public static float dividir (float num1, float num2) {
		return num1/num2;
	}
	
	/**
	 * La funci�n factorial, de forma recursiva, multiplica el n�mero introducido por el n�mero anterior hasta llegar a 1.
	 * �ste ser� el factorial de un n�mero. �sta funci�n retornar� un double
	 * ya que de lo contrario no se podr�a calcular un factorial superior a 31.
	 * El n�mero m�ximo de factorial que admite la funci�n es de 170.
	 * @param num introduccion de un n�mero entero queser� multiplicado pr s� mismo menos 1 (ATENCI�N el n�mero ha de ser menor o igual a 170)
	 * @return mum*factorial(num-1) de forma recursiva hasta llegar a 1 en declaraci�n de double
	 */
	public static double factorial (int num) {
		if (num <= 0)
			return 1;
		else
			return num * factorial(num-1);
	}
}
