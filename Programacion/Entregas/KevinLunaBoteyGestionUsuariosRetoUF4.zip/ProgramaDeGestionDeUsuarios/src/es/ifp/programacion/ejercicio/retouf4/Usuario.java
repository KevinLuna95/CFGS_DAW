package es.ifp.programacion.ejercicio.retouf4;
/**
 * Clase Usuario, permite instanciar un usuario.
 * @author Kevin Luna Botey
 *
 */
public class Usuario {
	private String nombre;
	private String apellidos;
	private String dni;
	private String email;
	private int telefono;
	
	/**
	 * Constructor de usuario mínimo
	 * @param nombre nombre de usuario String
	 * @param apellidos apellido de usuario String
	 * @param dni dni de usuario (Key) String
	 */
	public Usuario(String nombre, String apellidos, String dni) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;
	}
	
	/**
	 * Constructor de usuario completo String
	 * @param nombre nombre de usuario String
	 * @param apellidos apellido de usuario String
	 * @param dni dni de usuario (Key) String
	 * @param email email de usuario String
	 * @param telefono telefono de usuario int
	 */
	public Usuario(String nombre, String apellidos, String dni, String email, int telefono) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;
		this.email = email;
		this.telefono = telefono;
	}

	/**
	 * Obtiene el nombre
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Permite modificar el nombre
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Obtiene los apellidos
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * Permite modificar los apellidos
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * Obtiene el dni
	 * @return the dni
	 */
	public String getDni() {
		return dni;
	}

	/**
	 * Permite modificar el dni
	 * @param dni the dni to set
	 */
	public void setDni(String dni) {
		this.dni = dni;
	}

	/**
	 * Obtiene el email
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Permite modificar el email
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Obtiene el telefono
	 * @return the telefono
	 */
	public int getTelefono() {
		return telefono;
	}

	/**
	 * Permite modificar el telefono
	 * @param telefono the telefono to set
	 */
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	/**
	 * Sobreescribe el metodo toString para aportar el formato correcto de impresion
	 */
	@Override
	public String toString() {
		String res =  "Nombre: " + getNombre()+ "\n" + 
				"Apellidos: " + getApellidos()+ "\n" + 
				"dni: " + getDni();
				if(this.email != null) 
					res += "\n" + "Email: " + getEmail() + "\n";
				if(this.telefono != 0) 
					res += "Telefono: " + getTelefono();
		return res;
	}
	
	
}
	
	
