package es.ifp.programacion.ejercicio.retouf4;

import java.util.HashMap;
import java.util.Scanner;

import javax.annotation.processing.SupportedSourceVersion;

/**
 * Permite la gestion de los usuarios de una empreasa
 * 
 * @author Kevin Luna Botey
 * @version 0.0.1
 */
public class ProgramaPrincipal {

	public static void main(String[] args) {
		char opcion = '0';
		Scanner sc = new Scanner(System.in);
		HashMap<String, Usuario> mapa= new HashMap<String, Usuario>();

		Usuario usuario1 = new Usuario("Pepe","Lopez","48065888M");
		Usuario usuario2 = new Usuario("Antonio","Gomez", "99887766P","antongo2gmail.com",666555444);
		
		mapa.put(usuario1.getDni(), usuario1);
		mapa.put(usuario2.getDni(), usuario2);
		
		// gestionando el menu
		do {
			mostrarMenu();
			opcion = sc.nextLine().charAt(0);
			
			switch(opcion){
			case '1':
				crearUsuario(mapa);
				break;
			case '2':
				mostrarUsuarios(mapa);
				break;
			case '3':
				buscarUsuario(mapa);
				break;
			case '4':
				modificarUsuario(mapa);
				break;
			case '5':
				eliminarUsuario(mapa);
				break;
			case '6': 
				System.out.println("Fin del programa");
				break;
			default :System.out.println("Error en el dato");
			break;
			};
			
		} while(opcion != '6');
	}
	
	/**
	 * Permite modificar el usuario escogido.
	 * @param mapa la estructura de datos hashMap
	 */
	public static void modificarUsuario(HashMap<String, Usuario> mapa) {
		Scanner sc = new Scanner(System.in);
		char opcion = '0';
		String dni = "";
		Usuario usuario;
		System.out.println("Indica el DNI del usuario que desea modificar:");
		dni = sc.nextLine();
		
		if (mapa.containsKey(dni)) {
			usuario = mapa.get(dni);
			//Menu necesario para modificar cada opcion
			do {
			System.out.println("Estas en el menu de MODIFICACION");
			System.out.println("Que deseas modificar?");
			System.out.println("1. Nombre");
			System.out.println("2. Apellidos");
			System.out.println("3. DNI");
			System.out.println("4. Email");
			System.out.println("5. Telefono");
			System.out.println("6. Salir");
			System.out.println("Escoge la opcion");
			opcion = sc.nextLine().charAt(0);
			
			switch(opcion) {
				case '1':System.out.println("Indica el nuevo nombre:");
					usuario.setNombre(sc.nextLine());
					mapa.replace(dni, usuario);
					break;
				case '2':System.out.println("Indica los nuevos apellidos:");
					usuario.setApellidos(sc.nextLine());
					mapa.replace(dni, usuario);
					break;
				case '3':System.out.println("Indica el nuevo DNI:");
					dni = sc.nextLine();
					usuario.setDni(dni);
					mapa.replace(dni, usuario);
					usuario = mapa.get(dni);
					break;
				case '4':System.out.println("Indica el nuevo email:");
					usuario.setEmail(sc.nextLine());
					mapa.replace(dni, usuario);
					break;
				case '5':System.out.println("Indica el nuevo telefono:");
					usuario.setTelefono(Integer.parseInt(sc.nextLine()));
					mapa.replace(dni, usuario);
					break;
				case '6': break;
				default: System.out.println("La opcion no es correcta 6 para salir");
			}
			}while(opcion != '6');
		} else
			System.out.println("El DNI no ha sido encontrado");
	}
	
	/**
	 * Muestra todos los usuarios
	 * @param mapa la estructura de datos hashMap
	 */
	public static void mostrarUsuarios(HashMap<String, Usuario> mapa) {
		String tmp = "";
		for(String elemento : mapa.keySet()) {
			tmp +=mapa.get(elemento).toString();
			tmp +="\n"+"----------------------------------"+"\n";
		}
		System.out.println(tmp);
	}
	
	/**
	 * Permite la busqueda de un usuario concreto desde su DNI(Key)
	 * @param mapa la estructura de datos hashMap
	 */
	public static void buscarUsuario(HashMap<String, Usuario> mapa){
		String dni = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Indica el DNI que deseas buscar:");
		dni = sc.nextLine();
		
		if(mapa.containsKey(dni))
			System.out.println(mapa.get(dni).toString());
		else
			System.out.println("El DNI no ha sido encontrado");
	}
	
	/**
	 * Elimia un usuario mediante el DNI(Key)
	 * @param mapa la estructura de datos hashMap
	 */
	public static void eliminarUsuario(HashMap<String, Usuario> mapa){
		String dni = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Indica el DNI que deseas eliminar:");
		dni = sc.nextLine();
		
		if(mapa.containsKey(dni)) {
			System.out.println("Esta seguro que desea eliminarlo? S/N");
			if(sc.nextLine().toUpperCase().equals("S")) {
				mapa.remove(dni);
				System.out.println("El DNI "+ dni +" ha sido eliminado correctamente");
			}
			else
				System.out.println("No ha sido eliminado");
		}
		else
			System.out.println("El DNI no ha sido encontrado");
	}
	
	/**
	 * Muestra el menu principal
	 */
	public static void mostrarMenu() {
		System.out.println("===================================================");
		System.out.println("Opciones:");
		System.out.println("1. Crear Usuario");
		System.out.println("2. Ver todos los usuarios");
		System.out.println("3. Buscar un usuario");
		System.out.println("4. Modificar usuario");
		System.out.println("5. Eliminar un usuario");
		System.out.println("6. Salir");
		System.out.println("===================================================");
		System.out.println("Escoge la opcion entre el 1 y el 6");
	}

	/**
	 * Permite crear un nuevo usuario solicitando todos los datos. Email y telefono opcionales
	 * @param mapa la estructura de datos hashMap
	 */
	public static void crearUsuario(HashMap<String, Usuario> mapa) {
		String nombre = "";
		String apellidos = "";
		String dni = "";
		String email = "";
		int telefono = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduce el nombre del usuario");
		nombre = sc.nextLine();
		System.out.println("Introduce los apellidos del usuario");
		apellidos = sc.nextLine();
		System.out.println("Introduce el DNI del usuario");
		dni = sc.nextLine();
		System.out.println("Quieres intoducir email y telefono? S/N");
		if(sc.nextLine().toUpperCase().equals("S")) {
			System.out.println("Introduce el email del usuario");
			email = sc.nextLine();
			System.out.println("Introduce el telefono del usuario");
			telefono = Integer.parseInt(sc.nextLine());
			Usuario usuario = new Usuario(nombre, apellidos, dni, email, telefono);
			mapa.put(usuario.getDni(), usuario);
			System.out.println("Usuario: " + usuario.getNombre() + " " + usuario.getApellidos() + " creado correctamente");
		} else {
			Usuario usuario = new Usuario(nombre, apellidos, dni);
			mapa.put(usuario.getDni(), usuario);
			System.out.println("Usuario: " + usuario.getNombre() + " " + usuario.getApellidos() + " creado correctamente");
		}
	}
}


