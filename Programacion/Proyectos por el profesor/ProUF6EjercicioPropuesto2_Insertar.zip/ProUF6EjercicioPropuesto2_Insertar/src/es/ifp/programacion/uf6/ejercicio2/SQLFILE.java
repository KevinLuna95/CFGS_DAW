package es.ifp.programacion.uf6.ejercicio2;

public class SQLFILE {
	
	public static final String SQL_INSERT_DEPTO = "INSERT INTO DEPARTAMENTOS (dpto_no, nombre, localidad) VALUES (?,?,?)";
	

}
