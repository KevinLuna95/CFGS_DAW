package es.ifp.programacion.uf6.ejercicio.negocio;

public class DptoExistsException extends Exception {
	
	public DptoExistsException(String msg) {
		super(msg);
	}

}
