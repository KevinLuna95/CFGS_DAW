package es.ifp.programacion.uf6.ejercicio.negocio;

public class EmpleadoNotFoundException extends Exception {
	
	public EmpleadoNotFoundException(String msg) {
		super(msg);
	}

}
