package es.ifp.programacion.uf6.ejercicio.negocio;

public class DptoNotFoundException extends Exception {
	
	
	public DptoNotFoundException(String message) {
		super(message);
	}
	
	

}
