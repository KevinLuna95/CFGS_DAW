package es.ifp.programacion.poo.ejerciciopropuesto7;

public interface IDeportista {
	
	public void compitiendo();
}
